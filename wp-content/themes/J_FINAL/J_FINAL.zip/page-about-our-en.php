<?php 

get_header();

?>


  <div class="wrapper">
    <div class="inner light">
		<h2>Our Partners</h2>
		<p>IB agreement from Vantage Fx <br>
		VANTAGE FX PTY.LTD an Australian financial group regulated by Australian Securities and Investment Commission (ASIC) (AFSL Number 428901) hereby authorizes J MERIT PTY LTD as Vantage Fx Training Center, to undertake brand promotion business.
		</p>
		<a href="<?php bloginfo('template_url'); ?>/pdf/ib_agreement.pdf" target="_blank">IB AGREEMENT</a>
    </div>
  </div>


<?php
get_footer();
?>