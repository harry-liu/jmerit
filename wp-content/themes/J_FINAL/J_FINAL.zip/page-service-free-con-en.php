<?php 
get_header();
?>
  <!-- Begin Wrapper -->
  <div class="wrapper">
    <div class="inner light">
		  <h2>Free consultation</h2>
		  <p>At J Merit, our professional RG146 qualified consultants will help you on many aspects.</p>
		  <ul class="unordered">
		  	<li>Fundamental analysis</li>
		  	<li>Trading strategy </li>
		  	<li>Trading Psychology</li>
		  	<li>Indicators</li>
		  </ul>
    </div>
  </div>
  <!-- End Wrapper --> 

<?php
get_footer();
?>