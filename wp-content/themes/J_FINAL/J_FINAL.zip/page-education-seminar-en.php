<?php 

get_header();

?>


  <div class="wrapper">
    <div class="inner light">
		<h2>Seminar</h2>
		<p>Forex trading general knowledge seminar every Wednesday，please email us for attendance.</p>
    </div>
  </div>



<?php
get_footer();
?>