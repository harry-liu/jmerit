<?php 
get_header();
?>
  <!-- Begin Wrapper -->
  <div class="wrapper">
    <div class="inner light" style = "height:50vh">
	  <p>Please send account opening request to the email blow.</p>
	  <a href="">info@jmerit.com.au</a>
  	</div>
  </div>
  <!-- End Wrapper --> 

<?php
get_footer();
?>