<?php 

get_header();

?>


  <div class="wrapper">
    <div class="inner light">
		<h2>MT4 Manual</h2>
		<div class="overlay"><img src="<?php bloginfo('template_url'); ?>/images/mt.jpg" alt="" /></div>
		<div><a target="_blank" href="<?php bloginfo('template_url'); ?>/pdf/mt4_guide.pdf">MT4 Manual </a></div>
    </div>
  </div>



<?php
get_footer();
?>