<?php 

get_header();

?>


  <div class="wrapper">
    <div class="inner light">
		<h2>Learn Forex</h2>
		<h3>What is Forex?</h3>
		<p>The exchange of two countries’ currencies  on a recognized market. Forex trading is a popular type of investing because it provides investors to  make quick profits due to small changes in currency. Due to the different time zone around the world, forex trading takes place continuously. The market is open 24 hours 5 days with the most important world trading centres, which being located in Sydney, Tokyo, London and New York. The Forex market is the largest and most liquid market in the world with an average daily turnover of $5.8 trillion. There is no central marketplace control the Forex market, it is conducted over the counter. Forex is quoted by the global central banks and authoritative financial institutions. </p>
    </div>
  </div>



<?php
get_footer();
?>