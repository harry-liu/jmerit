<?php 
get_header();
?>
  <!-- End Top Wrapper --> 
  <!-- <div class="copyrights">Collect from <a href="http://www.cssmoban.com/"  title="网站模板">网站模板</a></div> -->
  <!-- Begin Wrapper -->
    <div class="wrapper">
    <div class="inner dark">
      <div class="page-intro clearfix">
        <h1 class="page-title">每日行情</h1>
      </div>
      <div id="portfolio">
        <ul class="items col4">

<!--           <li class="item">
            <div class="overlay"><a href="everyday_update_detail.php"><img src="images/post/p1.jpg" alt="" /></a></div>
            <div class="info">
              <h4 class="long-lined"><a href="portfolio-post.html">今日行情分析</a></h4>
              <p>由于美国上周五糟糕的非农数据使得美元大幅承压</p>
              <a href="everyday_update_detail.php" class="more">查看详情 →</a> </div>
          </li> -->
          <?php
          $recent_args = array(
              'numberposts' => '100' 
          );

          $recent_posts = new WP_Query( $recent_args );
          if ( $recent_posts -> have_posts() ) :
              while ( $recent_posts -> have_posts() ) : $recent_posts -> the_post();

              ?>
              <li class="item">
                <div class="overlay">
                  <a href="<?php the_permalink(); ?>">
                    <img src="<?php echo catch_that_image(); ?>" alt="" style = "width:238px;height:159px"/>
                    </a>
                </div>
                <div class="info">
                  <h4 class="long-lined">
                    <a href="<?php the_permalink(); ?>"><?php the_title() ?></a>
                  </h4>
                  <p><?php the_content( '', TRUE ); ?></p>
                  <a href="<?php the_permalink(); ?>" class="more">查看详情 →</a> 
                </div>
              </li>
              <?php

              endwhile;
          endif;
          ?>
        </ul>
      </div>
    </div>
  </div>
  <!-- End Wrapper --> 
<?php 
get_footer();
?>