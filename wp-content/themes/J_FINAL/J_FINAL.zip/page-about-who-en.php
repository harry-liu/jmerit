<?php 

get_header();

?>


  <div class="wrapper">
    <div class="inner light">
		<h2>Who is J Merit ？</h2>
		<p>J Merit is a Forex Introducing Broker, providing services in Forex, indices trading, commodities trading through MetaTrader 4 platform and cooperate with Vantage FX which is a leading Forex broker in Australia. <br>
With the head office based in Sydney, J Merit operates under the strict oversight        of the Australian Securities and Investment Commission (ASIC). <br>
The ASIC regulatory environment has been widely recognised as the most trusted regulatory commission worldwide and offers Forex traders the additional security which is rare to find in the global Forex trading industry. <br>
J Merit highly cooperate with Vantage FX and through the powerful stable Vantage FX MetaTrader 4 platform and can provide super-fast forex trading execution via fibre optic network. MT4 also has multiple mobile trading apps for iPhone and Android devices.
</p>
    </div>
  </div>



<?php
get_footer();
?>